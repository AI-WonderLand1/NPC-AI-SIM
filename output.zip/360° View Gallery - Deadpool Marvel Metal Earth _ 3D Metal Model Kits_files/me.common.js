﻿function goToByScroll(id) {
    var targetElem = document.getElementById(id);
    if (targetElem !== null) {
        var offsetpos = $("#" + id).offset().top;
        // Scroll
        $('html,body').animate({
            scrollTop: offsetpos
        }, 'slow');
    }
}

function initGotoObjectId() {
    var hash = window.location.hash;
    goToByScroll(hash.replace('#', ''));
}

function activeTopMenu() {
    $('.top-menu-right li a').removeClass('actived');
    var pathname = window.location.pathname;
    $('.top-menu-right li a').each(function () {
        var menuUrl = $(this).attr("href");
        if (menuUrl == pathname) {
            $(this).addClass('actived');
        }
    });
}

function imageExists(url, callback) {
    var img = new Image();
    img.onload = function () { callback(true); };
    img.onerror = function () { callback(false); };
    img.src = url;
}

function delay(callback, ms) {
    var timer = 0;
    return function () {
        var context = this, args = arguments;
        clearTimeout(timer);
        timer = setTimeout(function () {
            callback.apply(context, args);
        }, ms || 0);
    };
}

$(function () {
    $(window).load(function () {
        initGotoObjectId();
        activeTopMenu();
    });
});